---
name: Roadside Precision
colors:
  surface: '#001231'
  surface-dim: '#001231'
  surface-bright: '#283959'
  surface-container-lowest: '#000d27'
  surface-container-low: '#071b3a'
  surface-container: '#0c1f3e'
  surface-container-high: '#182a49'
  surface-container-highest: '#243455'
  on-surface: '#d8e2ff'
  on-surface-variant: '#d0c6ab'
  inverse-surface: '#d8e2ff'
  inverse-on-surface: '#1f3050'
  outline: '#999077'
  outline-variant: '#4d4732'
  surface-tint: '#e9c400'
  primary: '#fff6df'
  on-primary: '#3a3000'
  primary-container: '#ffd700'
  on-primary-container: '#705e00'
  inverse-primary: '#705d00'
  secondary: '#b5c4ff'
  on-secondary: '#00287c'
  secondary-container: '#0259f8'
  on-secondary-container: '#e3e7ff'
  tertiary: '#defcff'
  on-tertiary: '#00363a'
  tertiary-container: '#00f1ff'
  on-tertiary-container: '#006a70'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe16d'
  primary-fixed-dim: '#e9c400'
  on-primary-fixed: '#221b00'
  on-primary-fixed-variant: '#544600'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#b5c4ff'
  on-secondary-fixed: '#00164e'
  on-secondary-fixed-variant: '#003cae'
  tertiary-fixed: '#79f5ff'
  tertiary-fixed-dim: '#00dbe8'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f54'
  background: '#001231'
  on-background: '#d8e2ff'
  surface-variant: '#243455'
typography:
  display-hero:
    fontFamily: Chivo
    fontSize: 56px
    fontWeight: '900'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Chivo
    fontSize: 36px
    fontWeight: '900'
    lineHeight: 42px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Chivo
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Chivo
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Chivo
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Chivo
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  headline-md:
    fontFamily: Chivo
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
  headline-sm:
    fontFamily: Chivo
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers an urgent, highly authoritative, and dependable visual presence built for round-the-clock emergency roadside intervention. Designed specifically for drivers facing unexpected tyre failures, punctures, and commercial fleet breakdowns across the UK, the interface instills immediate calm, speed, and confidence.

The aesthetic fuses industrial high-contrast utility with modern, dark-mode glassmorphic depth:
- **Tone:** Mission-critical, swift, trustworthy, and ruggedly professional.
- **Visual Style:** Deep navy glassmorphism layered over inky structural backgrounds, illuminated by tactical gold focal points and electric blue diagnostic accents. 
- **Emotional Response:** Reassurance in vulnerability, instantaneous clarity of action, and seamless frictionless dispatch.

## Colors

The palette establishes high nighttime legibility and unmistakable call-to-action prominence:

- **Primary Background (`#0b1e3d`):** Deep oceanic navy serving as the foundational canvas for high contrast and sustained dark-mode comfort.
- **Section Alternate (`#061226`):** Abyss navy used for structural banding, alternate sectional modules, and elevated contrast panels.
- **Primary Accent (`#ffd700` / Hover `#f0c800`):** Vibrant hazard gold. Reserved strictly for primary emergency dispatch triggers, high-priority status indicators, and prime metrics. Text on gold elements must always be `#0b1e3d` in bold weight.
- **Secondary Accent (`#0058f7`):** Pure electric blue. Deployed conservatively for technical pill chips, live telemetry badges, verified driver icons, and non-blocking metadata.
- **Text & Content Hierarchy:**
  - High Emphasis / Headings: Pure White (`#ffffff`).
  - Secondary Copy & Subtitles: Silver Gray (`#9ca3af`).
  - Tertiary Metadata & Inactive Labels: Muted Steel (`#6b7280`).
- **Structural Lines & Outlines:** Translucent white (`rgba(255, 255, 255, 0.1)`) or deep tone borders (`rgba(11, 30, 61, 0.6)`), avoiding harsh solid lines to maintain clean depth.

## Typography

The type system balances industrial presence with utilitarian roadside legibility.

- **Headlines (Chivo):** An authoritative, technical grotesque with condensed proportions and razor-sharp junctions. Used in extra-bold and black weights to project confidence, urgent response capability, and rapid legibility even under stressful breakdown circumstances.
- **Body & Labels (Inter):** Highly legible, neutral sans-serif designed for optimum screen legibility. Provides effortless readability for pricing tables, tyre specifications (e.g., `225/45 R17 94W`), time estimates, and postcode lookups.
- **Hierarchy Rules:**
  - High-impact vehicle registration and price points must utilize `Chivo` in bold or extra-bold weights.
  - Tracking on all caps subheaders and pill badges must remain loose (`0.06em`) to ensure clear instant decipherability at a glance.

## Layout & Spacing

A strictly regimented 8pt spatial grid system ensures modular clarity across emergency workflows:

- **Desktop (1024px+):** 12-column layout with max-width container set to `1280px`. Gutters sit at `1.5rem` (`24px`) with safe outer margins of `2rem` (`32px`).
- **Tablet (768px - 1023px):** 8-column layout with `1.25rem` (`20px`) gutters and margins.
- **Mobile (up to 767px):** 4-column fluid layout with condensed `0.75rem` (`12px`) gutters and `1rem` (`16px`) outer margins, prioritizing thumb-zone dispatch buttons and large tap targets.
- **Layout Rhythms:**
  - Standard vertical stack separation between modular cards relies on `space-md` (`16px`) or `space-lg` (`24px`).
  - Hero sections and distinct operational breakdown tiers use `space-xl` (`40px`) to prevent visual crowding.

## Elevation & Depth

Visual hierarchy is maintained through subtle, tactical glassmorphism layered over structured navy surfaces rather than muddy box shadows:

- **Base Canvas:** Solid `#0b1e3d` or `#061226`.
- **Level 1 (Card & Module Surface):** Semi-transparent deep navy fill (`rgba(11, 30, 61, 0.70)` or `rgba(6, 18, 38, 0.85)`), layered with backdrop blur (`backdrop-blur-md`, 12px) and framed by a 1px border of `rgba(255, 255, 255, 0.1)`.
- **Level 2 (Active/Hover/Floating):** Raised cards and active selectors shift background to `rgba(16, 42, 86, 0.90)`, bordered by `rgba(255, 215, 0, 0.4)` (gold tint) and supported by a subtle diffused glow (`0 10px 25px -5px rgba(0, 0, 0, 0.5), 0 0 15px 0 rgba(255, 215, 0, 0.15)`).
- **Emergency Callouts & Modals:** Solid `#061226` backing combined with a 2px structural rim (`rgba(255, 215, 0, 0.8)`) to forcefully separate high-priority breakdown triggers from environmental noise.

## Shapes

The interface blends structural container reliability with ultra-ergonomic interactive touch targets:

- **Containers & Cards:** Sculpted with `rounded-2xl` (`1rem` / `16px`) to project modern automotive polish while maintaining distinct layout boundaries.
- **Action Elements & Micro-Badges:** Strict full-pill architecture (`rounded-full` / `9999px`) applied to all CTAs, search bars, status tags, and telephone triggers, maximizing visual affordance and thumb-friendly tap accessibility.
- **Form Controls:** Set to `rounded-xl` (`0.75rem` / `12px`) to strike a functional midpoint between the curved cards and pill buttons.

## Components

### Buttons
- **Primary Action (Call Dispatch / Book Now):**
  - Shape: `rounded-full` (pill).
  - Background: Vibrant Gold (`#ffd700`), transitioning to `#f0c800` on hover.
  - Text: `#0b1e3d`, `font-bold`, uppercase or semi-bold sentence case, tracking-wide.
  - Active state: Subtle scale down (`scale-95`).
- **Secondary Action (Tyre Catalog / Fleet Inquiries):**
  - Shape: `rounded-full`.
  - Background: `rgba(255, 255, 255, 0.05)`, border `1px solid rgba(255, 255, 255, 0.2)`.
  - Text: `#ffffff`, `font-semibold`.
  - Hover state: Background `rgba(255, 255, 255, 0.15)`, border `1px solid rgba(255, 255, 255, 0.4)`.

### Chips & Badges
- **Status & Feature Badges:** Pill-shaped (`rounded-full`), padding `0.25rem 0.75rem`.
- **Secondary Accent Chip:** Blue background (`#0058f7`) with `#ffffff` text, used for tags like "24/7 Rapid Response", "Van En Route", or specific tyre speed ratings.
- **Urgent/Warning Chip:** Gold surface (`rgba(255, 215, 0, 0.15)`) with `#ffd700` border and text.

### Cards
- **Structure:** `rounded-2xl`, background `rgba(11, 30, 61, 0.7)` or `rgba(6, 18, 38, 0.85)`, backdrop filter `blur(12px)`.
- **Border:** `1px solid rgba(255, 255, 255, 0.1)`.
- **Internal Padding:** `space-md` (mobile) to `space-lg` (desktop).

### Input Fields & Reg Lookup
- **Registration Lookup Box:**
  - Vehicle Reg Input: Flat bright yellow block or dark input with high-contrast text, `rounded-xl`, border `2px solid rgba(255, 255, 255, 0.15)`.
  - Standard Input Fields: Background `rgba(6, 18, 38, 0.6)`, text `#ffffff`, placeholder text `#6b7280`.
  - Focus state: Border transitions to `#ffd700` with an outer glow `0 0 0 2px rgba(255, 215, 0, 0.2)`.

### Lists & Service Tiers
- **Structure:** Flush card lists separated by dividers tinted with `rgba(255, 255, 255, 0.06)`.
- **Bullet Icons:** Checkmarks enclosed within small electric blue (`#0058f7`) circular badges or gold pips.

### Checkboxes & Radios
- **Radio Buttons (Tyre Size / Run-Flat Options):** Full pill segmented controls or card selectors. Active selection highlights with a 2px `#ffd700` border and deep navy fill.
- **Checkbox:** `rounded-md` (`4px`), background `rgba(6, 18, 38, 0.8)`, border `1px solid rgba(255, 255, 255, 0.2)`. Active check uses `#ffd700` fill with `#0b1e3d` tick icon.